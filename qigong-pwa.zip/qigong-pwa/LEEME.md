# A ritmo de TAO con Bea — App de Qigong

Este es el código completo de tu app, lista para publicarse en internet como
PWA (instalable en el móvil, sin pasar por App Store ni Google Play).

## ¿Qué te vas a encontrar al descomprimir?

Una carpeta con archivos de código. No necesitas entenderlos ni tocarlos
para publicar la app — solo necesitas seguir los pasos de abajo.

## Paso 1 — Crea una cuenta gratuita en GitHub

GitHub es donde vivirá el código. Es gratis.
→ https://github.com/signup

## Paso 2 — Crea un "repositorio" nuevo

1. Una vez dentro de GitHub, pulsa el botón verde **"New"** (o el "+" arriba a la derecha → "New repository")
2. Dale un nombre, por ejemplo: `a-ritmo-de-tao`
3. Déjalo en "Public", y pulsa **"Create repository"**
4. En la página que se abre, busca el enlace **"uploading an existing file"**
5. Arrastra ahí TODOS los archivos y carpetas que te he dado (manteniendo la
   estructura de carpetas tal cual)
6. Pulsa **"Commit changes"** abajo

## Paso 3 — Conecta ese repositorio con Vercel (publica la app)

Vercel es un servicio gratuito que coge tu código y lo convierte en una web
real, con su propia dirección.

1. Ve a → https://vercel.com/signup
2. Elige **"Continue with GitHub"** (así se conectan automáticamente)
3. Una vez dentro, pulsa **"Add New..." → "Project"**
4. Busca tu repositorio `a-ritmo-de-tao` y pulsa **"Import"**
5. Vercel detectará automáticamente que es un proyecto Vite — no cambies nada
6. Pulsa **"Deploy"**
7. Espera 1-2 minutos. Al terminar, te da una URL tipo:
   `a-ritmo-de-tao.vercel.app`

¡Esa URL ya es tu app, funcionando de verdad en internet!

## Paso 4 — Instalarla en un móvil

1. Abre esa URL desde el navegador del móvil (Safari en iPhone, Chrome en Android)
2. **iPhone:** pulsa el icono de compartir (cuadrado con flecha) → "Añadir a pantalla de inicio"
3. **Android:** Chrome mostrará un aviso automático "Añadir a pantalla de inicio", o desde el menú (⋮) → "Instalar app"

Aparecerá como un icono más, como cualquier app descargada de una tienda.

## Cada vez que quieras cambiar algo (textos, sesiones nuevas, colores)

Vuelves a este chat, me pides el cambio, te doy el archivo actualizado, lo
subes a GitHub (Paso 2.5 — sustituyendo el archivo viejo) y Vercel actualiza
la app sola en menos de un minuto. No hay que repetir todo el proceso.

## Sobre el dominio propio (opcional, más adelante)

Si más adelante quieres que la app viva en algo como `bea-qigong.com` en vez
de `.vercel.app`, compras el dominio (unos 10-15€/año, en Namecheap o
similar) y lo conectas desde el panel de Vercel en "Settings → Domains".
No es necesario para empezar.

## Sobre los pagos (Premium)

Este prototipo simula el desbloqueo Premium con un botón. Para cobrar de
verdad necesitarás conectar Stripe — es un paso aparte que podemos hacer
cuando quieras, una vez la app esté publicada y la hayas podido probar tú
misma y con gente cercana.
